<?php

header('Content-Type: application/json'); // Set header to JSON

// If login successful, get all cities
$cities = getAllCities();
echo json_encode($cities);

function getAllCities()
{
    // Connect to the database
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    $cities = array();

    if ($conn) {
        // Query to fetch all cities
        $query = "SELECT * FROM `CITIES`";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            // Fetch all cities
            while ($row = $result->fetch_assoc()) {
                $cities[] = $row;
            }
        }
        mysqli_close($conn);
    }
    return $cities;
}
