<?php


// Establishing connection
$conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

// Check if connection was successful
if ($conn) {
    // Formulate your SQL query
    $sql = "SELECT * FROM `USERS`;";

    // Execute the query
    $result = mysqli_query($conn, $sql);

    // Check if the query executed successfully
    if ($result) {
        // Fetch data from the result set (assuming you want to fetch rows as an associative array)
        while ($row = mysqli_fetch_assoc($result)) {
            // Process each row as needed
            print_r($row); // This is just an example, you might want to do something else with the data
        }

        // Free result set
        mysqli_free_result($result);
    } else {
        // Handle query execution error
        echo "Error executing the query: " . mysqli_error($conn);
    }

    // Close connection
    mysqli_close($conn);
} else {
    // Handle connection error
    echo "Unable to connect to the database.";
}
?>