<?php
header('Content-Type: application/json');

// Get user_id and tracking_no from request
$user_id = $_REQUEST['user_id'];
$tracking_no = $_REQUEST['tracking_no'];

// Call function to fetch shipments data
$shipmentsData = getShipmentsData($user_id, $tracking_no);

// Output shipments data as JSON
echo json_encode($shipmentsData);

function getShipmentsData($user_id, $tracking_no)
{
    // Connect to the database
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    $shipmentsData = array();

    if ($conn) {
        // Prepare the SQL query
        $sql = "SELECT 
    s.*, 
    fa.address_name AS address_from_name, 
    fa.address_line_1 AS address_from_line_1, 
    fa.address_line_2 AS address_from_line_2, 
    fa.city_id AS address_from_city_id, 
    fa.country_id AS address_from_country_id, 
    ta.address_name AS address_to_name, 
    ta.address_line_1 AS address_to_line_1, 
    ta.address_line_2 AS address_to_line_2, 
    ta.city_id AS address_to_city_id, 
    ta.country_id AS address_to_country_id, 
    um.user_name AS manager_username, 
    us.user_name AS sender_username, 
    ur.user_name AS receiver_username, 
    ue.user_name AS employee_username, 
    uc.user_name AS created_by_username, 
    uu.user_name AS updated_by_username 
FROM 
    SHIPMENTS s 
LEFT JOIN 
    ADDRESSES fa ON s.address_from_id = fa.address_id 
LEFT JOIN 
    ADDRESSES ta ON s.address_to_id = ta.address_id 
LEFT JOIN 
    USERS um ON s.manager_id = um.user_id 
LEFT JOIN 
    USERS us ON s.sender_id = us.user_id 
LEFT JOIN 
    USERS ur ON s.receiver_id = ur.user_id 
LEFT JOIN 
    USERS ue ON s.employee_id = ue.user_id 
LEFT JOIN 
    USERS uc ON s.created_by = uc.user_id 
LEFT JOIN 
    USERS uu ON s.updated_by = uu.user_id 
WHERE 
    um.user_id = 3;";
//  OR ue.user_id = $user_id 
//     OR um.user_id = $user_id 
//     OR s.tracking_no = '$tracking_no';
        // Execute the query
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch all rows
            while ($row = $result->fetch_assoc()) {
                $shipmentsData[] = $row;
            }
        }

        mysqli_close($conn);
    }
    return $shipmentsData;
}
?>
