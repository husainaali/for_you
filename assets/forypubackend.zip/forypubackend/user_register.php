<?php

header('Content-Type: application/json'); // Set header to JSON

// Retrieve POST data
$username   = $_POST['username'];
$password   = $_POST['password'];
$email      = $_POST['email'];
$fullName   = $_POST['fullName'];
$address    = $_POST['address'];
$contact1   = $_POST['contact1'];
$contact2   = $_POST['contact2'];
$role       = $_POST['role'];
$identityNo = $_POST['identityNo'];

// Call registerUser function
$result = registerUser($username, $password, $email, $fullName, $address, $contact1, $contact2, $role, $identityNo);

// Return result as JSON
echo json_encode($result);

function registerUser($username, $password, $email, $fullName, $address, $contact1, $contact2, $role, $identityNo) {
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    // Hash the password before storing it
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    if($conn){
        // Query to insert new user into the database
        $query = "INSERT INTO `USERS`(`user_name`, `password`, `email`, `full_name`, `address`, `contact_no1`, `contact_no2`, `registration_date`, `last_login`, `role`, `identity_no`) VALUES ('$username', '$hashedPassword', '$email', '$fullName', '$address', '$contact1', '$contact2','2023-12-12','2023-12-12' , '$role', '$identityNo')";

        if ($conn->query($query) === TRUE) {
            return array('success' => true, 'message' => 'User registered successfully'); // Registration successful
        } else {
            return array('error' => $conn->error, 'message' => 'Failed to register user'); // Error occurred
        }

        mysqli_close($conn);
    }   
}
?>