<?php
header('Content-Type: application/json');

    $shippingType =     $_REQUEST['shippingType'];
    $fromCountryId =    $_REQUEST['fromCountryId'];
    $toCountryId =      $_REQUEST['toCountryId'];
    // $shippingTypeG =     $_GET['shippingType'];
    // $fromCountryIdG =    $_GET['fromCountryId'];
    // $toCountryIdG =      $_GET['toCountryId'];
    // $shippingTypeP =     $_POST['shippingType'];
    // $fromCountryIdP =    $_POST['fromCountryId'];
    // $toCountryIdP =      $_POST['toCountryId'];



    // Get shipping rates
    $countries = getAllCountries($shippingType, $fromCountryId, $toCountryId);
    echo json_encode($countries);


function getAllCountries($shippingType,$fromCountryId,$toCountryId)
{
    
    // Connect to the database
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    $countries = array();

    if ($conn) {

    // Prepare the SQL query
    $sql = "SELECT
                m.commercial_name AS managerCommercialName,
                CASE 
                    WHEN c1.country_id = c2.country_id THEN 
                        CASE 
                            WHEN '$shippingType' = 'normal' THEN s.shipping_rat_local
                            WHEN '$shippingType' = 'fast' THEN s.shipping_rat_local_fast
                        END
                    ELSE 
                        CASE 
                            WHEN '$shippingType' = 'normal' THEN s.shipping_rat_international
                            WHEN '$shippingType' = 'fast' THEN s.shipping_rat_international_fast
                        END
                END AS shippingRat
            FROM
                SHIPPING_RAT s
            JOIN
                MANAGERS m ON s.created_by = m.manager_id
            JOIN
                COUNTRIES c1 ON c1.country_id = '$fromCountryId'
            JOIN
                COUNTRIES c2 ON c2.country_id = '$toCountryId'
            WHERE
                c1.country_id = '$fromCountryId'";

        // Execute the query
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch all rows
            while ($row = $result->fetch_assoc()) {
                $countries[] = $row;
            }
        }
        

        mysqli_close($conn);
    }
    return $countries;
}

