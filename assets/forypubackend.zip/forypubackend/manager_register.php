<?php

header('Content-Type: application/json');

$managerName     = $_POST['managerName'];
$password        = $_POST['password'];
$email           = $_POST['email'];
$commercialName  = $_POST['commercialName'];
$address         = $_POST['address'];
$companySize     = $_POST['companySize'];
$contact1        = $_POST['contact1'];
$contact2        = $_POST['contact2'];

$result = registerManager($managerName, $password, $email, $commercialName, $address, $companySize, $contact1, $contact2);

echo json_encode($result);

function registerManager($managerName, $password, $email, $commercialName, $address, $companySize, $contact1, $contact2) {
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    if($conn){
        $query = "INSERT INTO `MANAGERS`(`manager_name`, `password`, `email`, `commercial_name`, `address`, `company_size`, `contact_no1`, `contact_no2`) VALUES ('$managerName', '$hashedPassword', '$email', '$commercialName', '$address', '$companySize', '$contact1', '$contact2')";

        if ($conn->query($query) === TRUE) {
            mysqli_close($conn);
            return array('success' => true, 'message' => 'Manager registered successfully');
        } else {
            mysqli_close($conn);
            return array('error' => $conn->error, 'message' => 'Failed to register manager');
        }

    }   
}

