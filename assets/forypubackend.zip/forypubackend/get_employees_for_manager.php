<?php
header('Content-Type: application/json');

// Get manager_id from request
$managerId = $_REQUEST['manager_id'];

// Call function to fetch employees for the manager
$employees = getManagerEmployees($managerId);

// Output employees as JSON
echo json_encode($employees);

function getManagerEmployees($managerId)
{
    // Connect to the database
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    $employees = array();

    if ($conn) {
        // Prepare the SQL query
        $sql = "SELECT 
                `EMPLOYEES`.`employee_id`,
                `EMPLOYEES`.`employee_name`,
                `EMPLOYEES`.`contact_no1`,
                `EMPLOYEES`.`manager_id`,
                `EMPLOYEES`.`isActive`,
                `EMPLOYEES`.`full_name`,
                `AUTHENTICATIONS`.`auth_id`,
                `AUTHENTICATIONS`.`user_id`,
                `AUTHENTICATIONS`.`user_name`,
                `AUTHENTICATIONS`.`role`
        FROM `EMPLOYEES`
        INNER JOIN `AUTHENTICATIONS` ON `EMPLOYEES`.`employee_id` = `AUTHENTICATIONS`.`user_id`
        WHERE `EMPLOYEES`.`manager_id` = $managerId";

        // Execute the query
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch all rows
            while ($row = $result->fetch_assoc()) {
                $row['employee_id'] = (int) $row['employee_id'];
                $row['manager_id'] = (int) $row['manager_id'];
                $row['auth_id'] = (int) $row['auth_id'];
                $row['user_id'] = (int) $row['user_id'];
                $row['isActive'] = (bool) $row['isActive'];
                $employees[] = $row;
            }
        }

        mysqli_close($conn);
    }
    return $employees;
}
