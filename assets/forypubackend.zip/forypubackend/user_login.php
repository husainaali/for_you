<?php
header('Content-Type: application/json'); // Set header to JSON

$username = $_REQUEST['username'];
$password = $_REQUEST['password'];

$result = loginUser($username, $password);

echo json_encode($result);

function loginUser($username, $password)
{
    // Connect to the databases
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    if ($conn) {
        // Query to authenticate user and retrieve user data based on role
        $query = "SELECT a.user_id, a.user_name, a.role, a.password,
            CASE
                WHEN a.role = 'User' THEN u.email
                ELSE NULL
            END AS user_email,
            CASE
                WHEN a.role = 'User' THEN u.full_name
                WHEN a.role = 'Employee' THEN e.employee_name
                WHEN a.role = 'Manager' THEN m.manager_name
                ELSE NULL
            END AS full_name,
            CASE
                WHEN a.role = 'User' THEN u.address
                WHEN a.role = 'Manager' THEN m.address
                ELSE NULL
            END AS address,
            CASE
                WHEN a.role = 'User' THEN u.contact_no1
                WHEN a.role = 'Employee' THEN e.contact_no1
                WHEN a.role = 'Manager' THEN m.contact_no1
                ELSE NULL
            END AS contact_no1,
            CASE
                WHEN a.role = 'User' THEN u.contact_no2
                WHEN a.role = 'Manager' THEN m.contact_no2
                ELSE NULL
            END AS contact_no2,
            CASE
                WHEN a.role = 'User' THEN u.registration_date
                ELSE NULL
            END AS registration_date,
            CASE
                WHEN a.role = 'User' THEN u.last_login
                ELSE NULL
            END AS last_login,
            CASE
                WHEN a.role = 'User' THEN u.identity_no
                ELSE NULL
            END AS identity_no,
            CASE
                WHEN a.role = 'User' THEN u.occupation
                ELSE NULL
            END AS occupation,
            CASE
                WHEN a.role = 'Employee' THEN e.manager_id
                ELSE NULL
            END AS manager_id,
            CASE
                WHEN a.role = 'Employee' THEN e.isActive
                ELSE NULL
            END AS isActive,
            CASE
                WHEN a.role = 'Manager' THEN m.email
                ELSE NULL
            END AS manager_email,
            CASE
                WHEN a.role = 'Manager' THEN m.company_size
                ELSE NULL
            END AS company_size
        FROM AUTHENTICATIONS a
        LEFT JOIN USERS u ON a.user_id = u.user_id
        LEFT JOIN EMPLOYEES e ON a.user_id = e.employee_id
        LEFT JOIN MANAGERS m ON a.user_id = m.manager_id
        WHERE a.user_name = '$username'"; // Use the provided username

        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            // User found, verify password
            $row = $result->fetch_assoc();
            if (password_verify($password, $row['password'])) {
                // Login successful, include user data in the response





                $userData = array(
                    'user_id' => (int) $row['user_id'],
                    'user_name' => $row['user_name'],
                    'role' => $row['role'],
                    'user_email' => $row['user_email'],
                    'full_name' => $row['full_name'],
                    'address' => $row['address'],
                    'contact_no1' => $row['contact_no1'],
                    'contact_no2' => $row['contact_no2'],
                    'registration_date' => $row['registration_date'],
                    'last_login' => $row['last_login'],
                    'identity_no' => $row['identity_no'],
                    'occupation' => $row['occupation'],
                    'manager_id' => (int) $row['manager_id'],
                    'isActive' => (bool) $row['isActive'], // Convert to boolean
                    'manager_email' => $row['manager_email'],
                    'company_size' => $row['company_size'],
                );
                mysqli_close($conn);

                return array('success' => true, 'message' => 'Login successful', 'user_data' => $userData);
            } else {
                mysqli_close($conn);

                return array('error' => 'Invalid credentials', 'message' => 'Invalid username or password'); // Invalid credentials
            }
        } else {
            mysqli_close($conn);
            return array('error' => 'User not found', 'message' => 'User not found'); // User not found
        }
    }
}
