<?php

header('Content-Type: application/json'); // Set header to JSON

$userId = $_REQUEST['userId']; 
$addressId  = $_REQUEST['addressId'];
$role = $_REQUEST['role'];

if ($addressId == -1) {
    $addressId = ''; 
} else {
    $addressId = intval($addressId);
}
$addressName = $_REQUEST['addressName'];
$addressLine1 = $_REQUEST['addressLine1'];
$addressLine2 = $_REQUEST['addressLine2'];
$cityId = intval($_REQUEST['cityId']);
$countryId = intval($_REQUEST['countryId']);

$result = addOrUpdateAddress($addressId, $addressName, $addressLine1, $addressLine2, $cityId, $countryId, $userId,$role);

echo json_encode($result);

function addOrUpdateAddress($addressId, $addressName, $addressLine1, $addressLine2, $cityId, $countryId, $userId,$role) {
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    if($conn){
        if(!empty($addressId)) {
            $query = "UPDATE `ADDRESSES` SET `address_name`='$addressName', `address_line_1`='$addressLine1', `address_line_2`='$addressLine2', `city_id`='$cityId', `country_id`='$countryId' WHERE `address_id`='$addressId'";
        } else {
            $query = "INSERT INTO `ADDRESSES`(`address_name`, `address_line_1`, `address_line_2`, `city_id`, `country_id`) VALUES ('$addressName', '$addressLine1', '$addressLine2', '$cityId', '$countryId')";
        }

        if ($conn->query($query) === TRUE) {
            if (empty($addressId)) {
                $addressId = $conn->insert_id; 
                
                switch ($role) {
                    case 'User':
                        $addressQuery = "INSERT INTO `USERS_ADDRESSES`(`user_id`, `address_id`) VALUES ('$userId', '$addressId')";
                        break;
                    case 'Manager':
                        $addressQuery = "INSERT INTO `MANAGERS_ADDRESSES`(`manager_id`, `address_id`) VALUES ('$userId', '$addressId')";
                        break;
                    default:
                        return array('error' => 'Invalid role', 'message' => 'Failed to register user');
                    }
                if ($conn->query($addressQuery) !== TRUE) {
                    mysqli_close($conn);
                    return array('error' => $conn->error, 'message' => 'Failed to add user address'); // Error occurred while inserting into USERS_ADDRESSES
                }
            }
            
            mysqli_close($conn);
            return array('success' => true, 'message' => 'Address added/updated successfully', 'addressId' => $addressId); // Address added/updated successfully
        } else {
            mysqli_close($conn);
            return array('error' => $conn->error, 'message' => 'Failed to add/update address'); // Error occurred
        }

    }   
}

