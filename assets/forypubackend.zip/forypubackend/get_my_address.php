<?php
header('Content-Type: application/json');

// Get user_id and user_role from request
$user_id = $_REQUEST['user_id'];
$user_role = $_REQUEST['role'];

// Determine the appropriate table and user identifier based on user_role
if ($user_role === 'Manager') {
    $table_name = 'MANAGERS_ADDRESSES';
    $user_identifier = 'manager_id';
} else {
    $table_name = 'USERS_ADDRESSES';
    $user_identifier = 'user_id';
}

// Call function to fetch addresses for the user
$addresses = getUserAddresses($user_id, $table_name, $user_identifier);

// Output addresses as JSON
echo json_encode($addresses);

function getUserAddresses($user_id, $table_name, $user_identifier)
{
    // Connect to the database
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    $addresses = array();

    if ($conn) {
        // Prepare the SQL query
        $sql = "SELECT
                    CAST(a.address_id AS UNSIGNED) AS address_id,
                    a.address_name,
                    a.address_line_1,
                    a.address_line_2,
                    CAST(a.city_id AS UNSIGNED) AS city_id,
                    c.city_name,
                    CAST(c.country_id AS UNSIGNED) AS country_id,
                    co.country_name
                FROM
                    $table_name ua
                INNER JOIN
                    ADDRESSES a ON ua.address_id = a.address_id
                INNER JOIN
                    CITIES c ON a.city_id = c.city_id
                INNER JOIN
                    COUNTRIES co ON c.country_id = co.country_id
                WHERE
                    ua.$user_identifier = $user_id";

        // Execute the query
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Fetch all rows
            while ($row = $result->fetch_assoc()) {
                // Convert integer fields to integers
                $row['address_id'] = intval($row['address_id']);
                $row['city_id'] = intval($row['city_id']);
                $row['country_id'] = intval($row['country_id']);
                
                $addresses[] = $row;
            }
        }

        mysqli_close($conn);
    }
    return $addresses;
}

