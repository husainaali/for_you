<?php

header('Content-Type: application/json'); // Set header to JSON

    $countries = getAllCountries();
    echo json_encode($countries);

function getAllCountries()
{
    // Connect to the database
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    $countries = array();

    if ($conn) {
        // Query to fetch all countries
        $query = "SELECT * FROM `COUNTRIES`";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {
            // Fetch all countries
            while ($row = $result->fetch_assoc()) {
                $countries[] = $row;
            }
        }
        mysqli_close($conn);
    }
    return $countries;
}
?>
