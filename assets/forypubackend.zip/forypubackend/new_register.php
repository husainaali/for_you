<?php

header('Content-Type: application/json'); // Set header to JSON

// Retrieve POST data
$username       = $_REQUEST['username'];
$password       = $_REQUEST['password'];
$email          = $_REQUEST['email'];
$fullName       = $_REQUEST['fullName'];
$address        = $_REQUEST['address'];
$contact1       = $_REQUEST['contact1'];
$contact2       = $_REQUEST['contact2'];
$role           = $_REQUEST['role'];
$identityNo     = $_REQUEST['identityNo'];
$occupation     = $_REQUEST['occupation']; // Only for Users
$managerId      = $_REQUEST['manager_id']; // Only for Employees
$isActive       = $_REQUEST['isActive']; // Convert string to boolean
$commercialName = $_REQUEST['commercial_name']; // Only for Managers
$commercialID   = $_REQUEST['commercial_id']; // Only for Managers
$companySize    = $_REQUEST['company_size']; // Only for Managers

// Call registerUser function
$result = registerUser($username, $password, $email, $fullName, $address, $contact1, $contact2, $role, $identityNo, $occupation, $managerId, $isActive, $commercialName,$commercialID, $companySize);

// Return result as JSON
echo json_encode($result);

function registerUser($username, $password, $email, $fullName, $address, $contact1, $contact2, $role, $identityNo, $occupation, $managerId, $isActive, $commercialName,$commercialID, $companySize) {
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    // Hash the password before storing it
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    if($conn){
        switch ($role) {
            case 'User':
                // Query to insert new user into the USERS table
                $query = "INSERT INTO `USERS`(`user_name`, `password`, `email`, `full_name`, `address`, `contact_no1`, `contact_no2`, `registration_date`, `last_login`, `identity_no`, `occupation`) VALUES ('$username', '$hashedPassword', '$email', '$fullName', '$address', '$contact1', '$contact2','2023-12-12','2023-12-12' , '$identityNo', '$occupation')";
                break;
            case 'Manager':
                // Query to insert new user into the MANAGERS table
                $query = "INSERT INTO `MANAGERS`(`manager_name`, `commercial_name`,`commercial_id`, `email`, `address`, `company_size`, `contact_no1`, `contact_no2`) VALUES ('$username', '$commercialName', '$commercialID','$email', '$address', '$companySize', '$contact1', '$contact2')";
                break;
            case 'Employee':
                // Query to insert new user into the EMPLOYEES table
                $query = "INSERT INTO `EMPLOYEES`(`employee_name`,`full_name`,`contact_no1`, `manager_id`, `isActive`) VALUES ('$username', '$fullName','$contact1', '$managerId', '$isActive')";
                break;
            default:
                return array('error' => 'Invalid role', 'message' => 'Failed to register user');
        }

        if ($conn->query($query) === TRUE) {
            // Get the user/employee/manager ID
            $userId = $conn->insert_id;
            echo $isActive;

            // Query to insert authentication data
            $authQuery = "INSERT INTO `AUTHENTICATIONS` (`user_id`, `user_name`, `password`, `role`) VALUES ('$userId', '$username', '$hashedPassword', '$role')";
            if ($conn->query($authQuery) === TRUE) {
                mysqli_close($conn);

                return array('success' => true, 'message' => 'User registered successfully');
            } else {
                mysqli_close($conn);

                return array('error' => $conn->error, 'message' => 'Failed to register user');
            }
        } else {
            mysqli_close($conn);

            return array('error' => $conn->error, 'message' => 'Failed to register user');
        }

    }   
}

