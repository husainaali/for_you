<?php

function getAllCountriesAndCities()
{
    // Connect to the database
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    $data = array();

    if ($conn) {
        // Query to fetch all countries
        $query_countries = "SELECT * FROM `COUNTRIES`";
        $result_countries = $conn->query($query_countries);

        if ($result_countries->num_rows > 0) {
            // Fetch all countries
            while ($row_country = $result_countries->fetch_assoc()) {
                $country_id = (int)$row_country['country_id'];
                $data[$country_id]['country_id'] = $country_id;
                $data[$country_id]['country_name'] = $row_country['country_name'];
                $data[$country_id]['cities'] = array();
            }

            // Query to fetch all cities
            $query_cities = "SELECT * FROM `CITIES`";
            $result_cities = $conn->query($query_cities);

            if ($result_cities->num_rows > 0) {
                // Fetch all cities
                while ($row_city = $result_cities->fetch_assoc()) {
                    $country_id = (int)$row_city['country_id'];
                    $city_id = (int)$row_city['city_id'];
                    $data[$country_id]['cities'][] = [
                        'city_id' => $city_id,
                        'city_name' => $row_city['city_name'],
                        'country_id' => $country_id,
                        'zip_code' => $row_city['zip_code']
                    ];
                }
            }
        }
        mysqli_close($conn);
    }
    return array_values($data);
}

$countries_and_cities = getAllCountriesAndCities();
echo json_encode($countries_and_cities);

