<?php

header('Content-Type: application/json'); // Set header to JSON

$username   = $_REQUEST['username'];
$password   = $_REQUEST['password'];


$result = loginUser($username, $password);

echo json_encode($result);
function loginUser($username,$password) {
    
    
    // Connect to the database
    $conn = mysqli_connect('localhost', 'u111037185_foryouadmin', 'ForyouAdmin1', 'u111037185_foryouapp') or die("Unable to connect to database");

    if($conn){
        // Query to fetch user from the database

        $query = "SELECT * FROM `USERS` WHERE `user_name` = '$username' OR `email` ='$username'";
        $result = $conn->query($query);

        if ($result->num_rows > 0) {

            // User found, verify password
            $row = $result->fetch_assoc();
            if(password_verify($password, $row['password'])) {
                // Login successful, include user data in the response
                $userData = array(
                    'user_id' => (int)$row['user_id'],
                    'user_name' => $row['user_name'],
                    'email' => $row['email'],
                    'password' => '000',
                    'full_name' => $row['full_name'],
                    'address' => $row['address'],
                    'contact_no1' => $row['contact_no1'],
                    'contact_no2' => $row['contact_no2'],
                    'registration_date' => $row['registration_date'],
                    'last_login' => $row['last_login'],
                    'role' => $row['role'],
                    'identity_no' => $row['identity_no'],
                    'occupation' => $row['occupation']
                );
                return array('success' => true, 'message' => 'Login successful', 'user_data' => $userData);
            } else {
                return array('error' => 'Invalid credentials', 'message' => 'Invalid username or password'); // Invalid credentials
            }
        } else {
            return array('error' => 'User not found', 'message' => 'User not found'); // User not found
        }

        mysqli_close($conn);
    }   
}
?>